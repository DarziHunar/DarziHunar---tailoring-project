import React, { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, Text } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import AuthButton from "../components/AuthButton";
import AuthHeader from "../components/AuthHeader";
import AuthInput from "../components/AuthInput";
import { useAuth } from "../context/AuthContext";
import { C } from "../theme/colors";

type Props = { onBack: () => void; onSignup: () => void };

export default function LoginPage({ onBack, onSignup }: Props) {
  const { signIn, signInWithGoogle } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [googleSubmitting, setGoogleSubmitting] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password) {
      Alert.alert("Missing details", "Enter your email address and password.");
      return;
    }
    setSubmitting(true);
    try {
      await signIn(email, password);
    } catch (error) {
      Alert.alert("Login failed", error instanceof Error ? error.message : "Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView contentContainerStyle={{ padding: 24, paddingBottom: 48, flexGrow: 1 }} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag" automaticallyAdjustKeyboardInsets>
        <AuthHeader title="Login" onBack={onBack} />
        <Text style={{ fontSize: 25, fontWeight: "800", color: C.wine }}>Welcome Back!</Text>
        <Text style={{ color: C.muted, marginTop: 8, marginBottom: 25 }}>Login to continue with DarziHunar.</Text>
        <AuthInput placeholder="Email Address" value={email} onChangeText={setEmail} keyboardType="email-address" autoComplete="email" />
        <AuthInput placeholder="Password" value={password} onChangeText={setPassword} secure autoComplete="password" />
        <AuthButton title="Login" onPress={handleLogin} loading={submitting} disabled={submitting} />
        <AuthButton title="Continue with Google" outline onPress={async () => {
          setGoogleSubmitting(true);
          try { await signInWithGoogle(); }
          catch (error) { Alert.alert('Google sign-in failed', error instanceof Error ? error.message : 'Please try again.'); }
          finally { setGoogleSubmitting(false); }
        }} loading={googleSubmitting} disabled={submitting || googleSubmitting} />
        <Pressable onPress={onSignup} style={{ marginTop: 25, alignItems: "center" }}>
          <Text style={{ color: C.wine }}>Don’t have an account? Sign Up</Text>
        </Pressable>
      </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
