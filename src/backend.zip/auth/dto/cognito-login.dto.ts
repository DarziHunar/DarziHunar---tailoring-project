import { IsString, MinLength } from 'class-validator';

export class CognitoLoginDto {
  @IsString()
  @MinLength(20)
  idToken: string;
}
