import { apiRequest } from './api';

export type TailorProfile = {
  id: number;
  userId: number;
  fullName?: string | null;
  shopName: string;
  bio?: string | null;
  categories: string[];
  experienceYears?: number | null;
  specialization?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  verified: boolean;
  rating: number;
  startingPrice: number;
  acceptingOrders: boolean;
  createdAt?: string;
  updatedAt?: string;
  user?: { fullName?: string | null };
};

export type TailorProfilePayload = {
  shopName: string;
  bio?: string;
  categories: string[];
  experienceYears?: number;
  specialization?: string;
  startingPrice?: number;
  acceptingOrders?: boolean;
  latitude?: number;
  longitude?: number;
};

export const tailorService = {
  list() {
    return apiRequest<TailorProfile[]>('/tailors');
  },
  getCategories() {
    return apiRequest<string[]>('/tailors/categories');
  },
  getByCategory(category: string) {
    return apiRequest<TailorProfile[]>(`/tailors/by-category?category=${encodeURIComponent(category)}`);
  },
  getById(id: number) {
    return apiRequest<TailorProfile>(`/tailors/${id}`);
  },
  getMine(token: string) {
    return apiRequest<TailorProfile>('/tailors/me', { token });
  },
  create(payload: TailorProfilePayload, token: string) {
    return apiRequest<TailorProfile>('/tailors', { method: 'POST', token, body: payload });
  },
  update(id: number, payload: Partial<TailorProfilePayload>, token: string) {
    return apiRequest<TailorProfile>(`/tailors/${id}`, { method: 'PATCH', token, body: payload });
  },
};
