import * as AuthSession from 'expo-auth-session';
import * as WebBrowser from 'expo-web-browser';

WebBrowser.maybeCompleteAuthSession();

const domain = process.env.EXPO_PUBLIC_COGNITO_DOMAIN?.replace(/^https?:\/\//, '').replace(/\/$/, '');
const clientId = process.env.EXPO_PUBLIC_COGNITO_CLIENT_ID;
const redirectUri = process.env.EXPO_PUBLIC_COGNITO_REDIRECT_URI || AuthSession.makeRedirectUri({ scheme: 'darzihunar', path: 'callback' });

export const cognitoAuthService = {
  async signInWithGoogle(): Promise<string> {
    if (!domain || !clientId) {
      throw new Error('Google sign-in is not configured. Set EXPO_PUBLIC_COGNITO_DOMAIN and EXPO_PUBLIC_COGNITO_CLIENT_ID in mobile/.env.');
    }

    const discovery = await AuthSession.fetchDiscoveryAsync(`https://${domain}`);
    const request = new AuthSession.AuthRequest({
      clientId,
      redirectUri,
      responseType: AuthSession.ResponseType.Code,
      scopes: ['openid', 'email', 'profile'],
      usePKCE: true,
      extraParams: { identity_provider: 'Google' },
    });

    const result = await request.promptAsync(discovery);
    if (result.type === 'cancel' || result.type === 'dismiss') {
      throw new Error('Google sign-in was cancelled.');
    }
    if (result.type !== 'success' || !result.params.code) {
      throw new Error(result.type === 'error' ? result.error?.message || 'Google sign-in failed.' : 'Google sign-in did not return an authorization code.');
    }
    if (!request.codeVerifier) throw new Error('PKCE verifier was not created. Restart the sign-in flow.');

    const tokenResponse = await AuthSession.exchangeCodeAsync({
      clientId,
      code: result.params.code,
      redirectUri,
      extraParams: { code_verifier: request.codeVerifier },
    }, discovery);

    if (!tokenResponse.idToken) throw new Error('Cognito did not return an ID token. Check the app client OAuth settings and openid scope.');
    return tokenResponse.idToken;
  },
};
