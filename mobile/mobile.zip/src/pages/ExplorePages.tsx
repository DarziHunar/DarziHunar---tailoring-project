import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import BottomNavigation from '../components/BottomNavigation';
import { useAuth } from '../context/AuthContext';
import { ordersService, type CustomerOrder } from '../services/ordersService';
import { C } from '../theme/colors';
import type { MainTab } from '../types/navigation';

type CategoryItem = { name: string; detail: string };
type TailorItem = { name: string; rating: number | string; distance: string };
type CreationItem = { name: string; category: string; price: string; image: string };

type FrameProps = React.PropsWithChildren<{
  title: string;
  subtitle?: string;
  onBack: () => void;
  activeTab: MainTab;
  onNavigate: (tab: MainTab) => void;
}>;

const palette = {
  ink: '#302326',
  wine: C.wine,
  muted: C.muted,
  white: '#FFFFFF',
  border: '#E8DED6',
  soft: '#F3E9DC',
};

function PageFrame({ title, subtitle, onBack, activeTab, onNavigate, children }: FrameProps) {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingTop: 8, paddingBottom: 14 }}>
        <Pressable onPress={onBack} accessibilityRole="button" accessibilityLabel="Go back" style={{ padding: 8, marginRight: 8 }}>
          <Text style={{ color: C.wine, fontSize: 30, lineHeight: 32 }}>‹</Text>
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={{ color: C.wine, fontSize: 21, fontWeight: '800' }}>{title}</Text>
          {!!subtitle && <Text style={{ color: C.muted, fontSize: 12, marginTop: 3 }}>{subtitle}</Text>}
        </View>
      </View>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }} showsVerticalScrollIndicator={false}>
        {children}
      </ScrollView>
      <BottomNavigation activeTab={activeTab} onNavigate={onNavigate} />
    </SafeAreaView>
  );
}

function SectionTitle({ children }: React.PropsWithChildren) {
  return <Text style={{ color: palette.ink, fontSize: 19, fontWeight: '800', marginTop: 12, marginBottom: 12 }}>{children}</Text>;
}

function InfoCard({ title, description, onPress }: { title: string; description?: string; onPress?: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={{ backgroundColor: palette.white, borderWidth: 1, borderColor: palette.border, borderRadius: 18, padding: 17, marginBottom: 11 }}
    >
      <Text style={{ color: palette.ink, fontSize: 16, fontWeight: '700' }}>{title}</Text>
      {!!description && <Text style={{ color: palette.muted, fontSize: 13, marginTop: 6, lineHeight: 19 }}>{description}</Text>}
      {!!onPress && <Text style={{ color: C.wine, fontSize: 13, fontWeight: '700', marginTop: 9 }}>View details →</Text>}
    </Pressable>
  );
}

export function CategoryPage({
  category,
  onBack,
  onSelectGarment,
  onNavigate,
}: {
  category: CategoryItem;
  onBack: () => void;
  onSelectGarment: (garment: string) => void;
  onNavigate: (tab: MainTab) => void;
}) {
  const choices: Record<string, string[]> = {
    Women: ['Sarees', 'Salwar Suits', 'Kurtas', 'Dresses', 'Lehengas', 'Blouses'],
    Men: ['Shirts', 'Kurtas', 'Trousers', 'Blazers', 'Sherwanis'],
    Teenagers: ['Casual Wear', 'Party Wear', 'Traditional Wear', 'Custom Outfits'],
    Children: ['Frocks', 'Kids Kurtas', 'Birthday Outfits', 'School Wear'],
  };
  const garments = choices[category.name] ?? ['Custom Outfits', 'Traditional Wear', 'Casual Wear'];

  return (
    <PageFrame title={category.name} subtitle={category.detail} onBack={onBack} activeTab="explore" onNavigate={onNavigate}>
      <Text style={{ color: palette.muted, lineHeight: 21, marginBottom: 8 }}>
        Choose the garment you would like to get stitched. You can explore designs and find a tailor in the next step.
      </Text>
      <SectionTitle>Choose a garment</SectionTitle>
      {garments.map((item) => <InfoCard key={item} title={item} description="Explore styles and tailoring options" onPress={() => onSelectGarment(item)} />)}
    </PageFrame>
  );
}

export function TailorsPage({
  tailors,
  onBack,
  onSelect,
  onNavigate,
}: {
  tailors: TailorItem[];
  onBack: () => void;
  onSelect: (tailor: TailorItem) => void;
  onNavigate: (tab: MainTab) => void;
}) {
  return (
    <PageFrame title="Tailor Masters" subtitle="Meet the hands behind the craft" onBack={onBack} activeTab="explore" onNavigate={onNavigate}>
      <Text style={{ color: palette.muted, fontSize: 13, marginBottom: 14 }}>These are sample profiles for the current frontend preview, not live backend listings.</Text>
      {tailors.map((tailor, index) => (
        <Pressable key={`${tailor.name}-${index}`} onPress={() => onSelect(tailor)} style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: palette.white, borderColor: palette.border, borderWidth: 1, borderRadius: 18, padding: 15, marginBottom: 12 }}>
          <View style={{ width: 58, height: 58, borderRadius: 17, backgroundColor: palette.soft, alignItems: 'center', justifyContent: 'center', marginRight: 13 }}>
            <Text style={{ fontSize: 27, color: C.wine }}>✂</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: palette.ink, fontSize: 16, fontWeight: '800' }}>{tailor.name}</Text>
            <Text style={{ color: C.wine, marginTop: 5 }}>★ {tailor.rating} · {tailor.distance}</Text>
            <Text style={{ color: palette.muted, fontSize: 12, marginTop: 4 }}>Sample profile</Text>
          </View>
          <Text style={{ color: C.wine, fontSize: 25 }}>›</Text>
        </Pressable>
      ))}
      {tailors.length === 0 && <EmptyState title="No tailors to show" body="Tailor profiles will appear here when they are available." />}
    </PageFrame>
  );
}

export function TailorDetailPage({
  tailor,
  onBack,
  onBrowseDesigns,
  onNavigate,
}: {
  tailor: TailorItem;
  onBack: () => void;
  onBrowseDesigns: () => void;
  onNavigate: (tab: MainTab) => void;
}) {
  return (
    <PageFrame title="Tailor Profile" subtitle="Tailor information" onBack={onBack} activeTab="explore" onNavigate={onNavigate}>
      <View style={{ backgroundColor: palette.white, borderRadius: 22, borderWidth: 1, borderColor: palette.border, padding: 22, alignItems: 'center', marginTop: 4 }}>
        <View style={{ width: 94, height: 94, borderRadius: 28, backgroundColor: palette.soft, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 43, color: C.wine }}>✂</Text>
        </View>
        <Text style={{ color: palette.ink, fontSize: 22, fontWeight: '800', marginTop: 15 }}>{tailor.name}</Text>
        <Text style={{ color: C.wine, marginTop: 7 }}>★ {tailor.rating} · {tailor.distance}</Text>
        <Text style={{ color: palette.muted, fontSize: 12, textAlign: 'center', marginTop: 12 }}>Sample profile · Live tailor details will be connected to the backend later.</Text>
      </View>
      <SectionTitle>About this tailor</SectionTitle>
      <InfoCard title="Services" description="Custom stitching and design consultation details will appear here once live tailor profiles are connected." />
      <InfoCard title="Availability" description="Working hours and appointment availability are not connected yet." />
      <Pressable onPress={onBrowseDesigns} style={{ backgroundColor: C.wine, borderRadius: 15, padding: 16, alignItems: 'center', marginTop: 8 }}>
        <Text style={{ color: '#FFFFFF', fontWeight: '800' }}>Browse designs</Text>
      </Pressable>
    </PageFrame>
  );
}

export function CreationDetailPage({
  creation,
  onBack,
  onFindTailor,
  onNavigate,
}: {
  creation: CreationItem;
  onBack: () => void;
  onFindTailor: () => void;
  onNavigate: (tab: MainTab) => void;
}) {
  return (
    <PageFrame title="Design Details" subtitle="Inspiration for your next outfit" onBack={onBack} activeTab="explore" onNavigate={onNavigate}>
      <View style={{ backgroundColor: palette.white, borderRadius: 22, borderWidth: 1, borderColor: palette.border, overflow: 'hidden' }}>
        <Image source={{ uri: creation.image }} resizeMode="cover" style={{ width: '100%', height: 360, backgroundColor: palette.soft }} />
        <View style={{ padding: 17 }}>
          <Text style={{ color: palette.ink, fontSize: 21, fontWeight: '800' }}>{creation.name}</Text>
          <Text style={{ color: palette.muted, marginTop: 7 }}>{creation.category}</Text>
          <Text style={{ color: C.wine, fontSize: 17, fontWeight: '800', marginTop: 11 }}>{creation.price}</Text>
        </View>
      </View>
      <Text style={{ color: palette.muted, lineHeight: 21, marginTop: 16 }}>
        This is an inspiration listing. Final pricing, fabric, measurements and delivery details should be confirmed with the selected tailor.
      </Text>
      <Pressable onPress={onFindTailor} style={{ backgroundColor: C.wine, borderRadius: 15, padding: 16, alignItems: 'center', marginTop: 20 }}>
        <Text style={{ color: '#FFFFFF', fontWeight: '800' }}>Find a tailor for this design</Text>
      </Pressable>
    </PageFrame>
  );
}

function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <View style={{ backgroundColor: palette.white, borderRadius: 20, borderColor: palette.border, borderWidth: 1, padding: 25, alignItems: 'center', marginTop: 20 }}>
      <Text style={{ fontSize: 36, color: C.wine }}>✳</Text>
      <Text style={{ color: palette.ink, fontSize: 18, fontWeight: '800', marginTop: 10 }}>{title}</Text>
      <Text style={{ color: palette.muted, lineHeight: 20, textAlign: 'center', marginTop: 7 }}>{body}</Text>
    </View>
  );
}

export function FavoritesPage({ onBack, onNavigate }: { onBack: () => void; onNavigate: (tab: MainTab) => void }) {
  return <PageFrame title="Favorites" subtitle="Your saved styles and tailors" onBack={onBack} activeTab="favorites" onNavigate={onNavigate}>
    <EmptyState title="No favorites yet" body="Save a design or tailor you love, and it will be available here." />
  </PageFrame>;
}

export function OrdersPage({ onBack, onNavigate }: { onBack: () => void; onNavigate: (tab: MainTab) => void }) {
  const { accessToken } = useAuth();
  const [orders, setOrders] = useState<CustomerOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    if (!accessToken) { setLoading(false); return; }
    ordersService.list(accessToken).then((result) => { if (active) setOrders(Array.isArray(result) ? result : []); })
      .catch((err) => { if (active) setError(err instanceof Error ? err.message : 'Unable to load orders.'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [accessToken]);
  return <PageFrame title="My Orders" subtitle="Track your tailoring requests" onBack={onBack} activeTab="orders" onNavigate={onNavigate}>
    {loading ? <ActivityIndicator color={C.wine} style={{ marginTop: 35 }} /> : error ? <EmptyState title="Could not load orders" body={error} /> : orders.length === 0 ? <EmptyState title="No orders yet" body="Your confirmed tailoring orders will appear here." /> : orders.map((order) => (
      <View key={order.id} style={{ backgroundColor: C.card, borderRadius: 18, borderWidth: 1, borderColor: C.border, padding: 16, marginTop: 12 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={{ color: C.wine, fontSize: 16, fontWeight: '900' }}>Order #{order.id}</Text>
          <Text style={{ color: C.gold, fontWeight: '800', fontSize: 12 }}>{order.status.replace(/_/g, ' ')}</Text>
        </View>
        <Text style={{ color: C.text, marginTop: 8, fontWeight: '700' }}>{order.tailor?.shopName || 'Selected tailor'}</Text>
        {(order.items || []).map((item) => <View key={item.id} style={{ marginTop: 8 }}>
          <Text style={{ color: C.text }}>{item.garmentType}{item.fabric ? ` · ${item.fabric}` : ''}{item.sizeLabel ? ` · ${item.sizeLabel}` : ''}</Text>
          <Text style={{ color: C.muted, fontSize: 11, marginTop: 3 }}>{Object.keys(item.measurements || {}).length} measurements · {item.measurementUnit || 'cm'}</Text>
        </View>)}
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 13, paddingTop: 12, borderTopWidth: 1, borderTopColor: C.border }}>
          <Text style={{ color: C.muted, fontSize: 12 }}>{new Date(order.createdAt).toLocaleDateString()}</Text>
          <Text style={{ color: C.wine, fontWeight: '900' }}>₹{Number(order.totalAmount).toLocaleString('en-IN')}</Text>
        </View>
      </View>
    ))}
  </PageFrame>;
}

export function ExplorePage({
  categories,
  tailors,
  onBack,
  onOpenCategory,
  onViewAllTailors,
  onSelectTailor,
  onNavigate,
}: {
  categories: CategoryItem[];
  tailors: TailorItem[];
  onBack: () => void;
  onOpenCategory: (category: CategoryItem) => void;
  onViewAllTailors: () => void;
  onSelectTailor: (tailor: TailorItem) => void;
  onNavigate: (tab: MainTab) => void;
}) {
  return <PageFrame title="Explore" subtitle="Discover styles and tailoring" onBack={onBack} activeTab="explore" onNavigate={onNavigate}>
    <SectionTitle>Browse by category</SectionTitle>
    {categories.map((category) => <InfoCard key={category.name} title={category.name} description={category.detail} onPress={() => onOpenCategory(category)} />)}
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12, marginBottom: 12 }}>
      <Text style={{ color: palette.ink, fontSize: 19, fontWeight: '800' }}>Tailor Masters</Text>
      <Pressable onPress={onViewAllTailors}><Text style={{ color: C.wine, fontWeight: '700' }}>View all →</Text></Pressable>
    </View>
    {tailors.slice(0, 3).map((tailor, index) => <InfoCard key={`${tailor.name}-${index}`} title={tailor.name} description={`★ ${tailor.rating} · ${tailor.distance}`} onPress={() => onSelectTailor(tailor)} />)}
  </PageFrame>;
}

export function MeasurementsPage({ onBack, onNavigate }: { onBack: () => void; onNavigate: (tab: MainTab) => void }) {
  const groups = [
    { title: 'Upper body', items: 'Chest, shoulder, neck, sleeve length' },
    { title: 'Torso', items: 'Waist, hips, top length' },
    { title: 'Lower body', items: 'Inseam, outseam, thigh, ankle' },
  ];
  return <PageFrame title="Measurements" subtitle="Keep your fit details in one place" onBack={onBack} activeTab="measurements" onNavigate={onNavigate}>
    <Text style={{ color: palette.muted, lineHeight: 21, marginTop: 4 }}>Measurement profiles will help tailors understand your preferred fit. This screen is currently a frontend layout; saving measurements will be connected when the backend endpoint is available.</Text>
    <SectionTitle>Measurement guide</SectionTitle>
    {groups.map((group) => <InfoCard key={group.title} title={group.title} description={group.items} />)}
    <View style={{ backgroundColor: palette.soft, borderRadius: 16, padding: 16, marginTop: 6 }}>
      <Text style={{ color: palette.ink, fontWeight: '700' }}>A better fit starts with accurate measurements.</Text>
      <Text style={{ color: palette.muted, marginTop: 6, lineHeight: 19 }}>Ask your tailor to take or verify your measurements before an order is confirmed.</Text>
    </View>
  </PageFrame>;
}

export function SearchPage({
  initialQuery,
  categories,
  tailors,
  onBack,
  onOpenCategory,
  onSelectTailor,
  onNavigate,
}: {
  initialQuery: string;
  categories: CategoryItem[];
  tailors: TailorItem[];
  onBack: () => void;
  onOpenCategory: (category: CategoryItem) => void;
  onSelectTailor: (tailor: TailorItem) => void;
  onNavigate: (tab: MainTab) => void;
}) {
  const [query, setQuery] = useState(initialQuery);
  const normalized = query.trim().toLowerCase();
  const matchedCategories = useMemo(() => categories.filter((item) => `${item.name} ${item.detail}`.toLowerCase().includes(normalized)), [categories, normalized]);
  const matchedTailors = useMemo(() => tailors.filter((item) => item.name.toLowerCase().includes(normalized)), [tailors, normalized]);

  return <PageFrame title="Search" subtitle="Find styles, garments and tailors" onBack={onBack} activeTab="explore" onNavigate={onNavigate}>
    <TextInput value={query} onChangeText={setQuery} placeholder="Search outfits, styles, tailors..." placeholderTextColor={C.muted} autoFocus returnKeyType="search" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: palette.border, borderRadius: 15, paddingHorizontal: 16, paddingVertical: 14, color: palette.ink, fontSize: 15 }} />
    {!normalized ? <EmptyState title="Start exploring" body="Type a garment, category or tailor name to see matching sample results." /> : <>
      <SectionTitle>Categories</SectionTitle>
      {matchedCategories.map((item) => <InfoCard key={item.name} title={item.name} description={item.detail} onPress={() => onOpenCategory(item)} />)}
      <SectionTitle>Tailors</SectionTitle>
      {matchedTailors.map((item, index) => <InfoCard key={`${item.name}-${index}`} title={item.name} description={`★ ${item.rating} · ${item.distance}`} onPress={() => onSelectTailor(item)} />)}
      {matchedCategories.length === 0 && matchedTailors.length === 0 && <EmptyState title="No matches found" body="Try a different search term." />}
    </>}
  </PageFrame>;
}

export function LocationPage({ onBack, onSave, onNavigate }: { onBack: () => void; onSave: (location: string) => void; onNavigate: (tab: MainTab) => void }) {
  const [location, setLocation] = useState('');
  return <PageFrame title="Choose Location" subtitle="Enter your area or PIN code" onBack={onBack} activeTab="home" onNavigate={onNavigate}>
    <Text style={{ color: palette.muted, lineHeight: 21, marginBottom: 15 }}>Add a location to personalize nearby tailor discovery. Location is stored only in this app session for now.</Text>
    <TextInput value={location} onChangeText={setLocation} placeholder="City, area or PIN code" placeholderTextColor={C.muted} autoCapitalize="words" returnKeyType="done" style={{ backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: palette.border, borderRadius: 15, paddingHorizontal: 16, paddingVertical: 14, color: palette.ink, fontSize: 15 }} />
    <Pressable disabled={!location.trim()} onPress={() => onSave(location.trim())} style={{ backgroundColor: location.trim() ? C.wine : '#B9A8AA', borderRadius: 15, padding: 16, alignItems: 'center', marginTop: 16 }}>
      <Text style={{ color: '#FFFFFF', fontWeight: '800' }}>Save location</Text>
    </Pressable>
  </PageFrame>;
}
